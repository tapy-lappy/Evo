// import 'reflect-metadata'   //must be first in list to prevent error: Cannot resolve all parameters for 'Parser'(?).... ==> https://github.com/angular/angular/issues/13609
// require('zone.js/dist/zone');          //Error: Angular requires Zone.js prolyfill
"use strict";
// Angular - this file only imports the application's third-party modules
require("@angular/platform-browser");
require("@angular/platform-browser-dynamic");
require("@angular/core");
require("@angular/common");
require("@angular/http");
require("@angular/router");
require("@angular/forms");
// RxJS
require("rxjs");
// Other vendors for example jQuery, Lodash or Bootstrap
// You can import js, ts, css, sass, ... 
//# sourceMappingURL=vendor.js.map