"use strict";
const platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
const app_module_1 = require("./Modules/app.module");
const platform = platform_browser_dynamic_1.platformBrowserDynamic();
platform.bootstrapModule(app_module_1.AppModule);
// import 'angular2-universal-polyfills/browser';
// import { platformUniversalDynamic } from 'angular2-universal';
//Boot the application, either now or when the DOM content is loaded
//const platform = platformUniversalDynamic();
const bootApplication = () => { platform.bootstrapModule(app_module_1.AppModule); };
if (document.readyState === 'complete') {
    bootApplication();
}
else {
    document.addEventListener('DOMContentLoaded', bootApplication);
}
//# sourceMappingURL=main.js.map