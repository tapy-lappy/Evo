﻿namespace Configuration.Enums
{
    public enum TravelServiceEnum
    {
        Currencies = 0,
        Locales
    }
}