﻿export class Currency {
    Code: string;
    Symbol: string;
}