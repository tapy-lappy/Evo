export interface Resolvable{
    //Used it, to mark type as DI resolvable, because it's impossible to interfere type into DI helper
    //The reason described here: http://stackoverflow.com/a/41090446
}