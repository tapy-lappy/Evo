﻿namespace TravelOrganizer.Api.Config.Section
{
    public class SkyScanner
    {
        public string SkyScannerTravelApiServiceUrl { get; set; } = "Not defined";
        public string SkyScannerTravelApiKey { get; set; } = "Not defined";
    }
}